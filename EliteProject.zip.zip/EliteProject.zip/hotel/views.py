from django.shortcuts import render,redirect, get_object_or_404
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate 
from hotel.models import Contact,Post,Resort,RoomIn,District,DiningOption,ViewType
from .models import Post
from .forms import Contactform,postform
from django.views import View
from django.views.generic import FormView
from django.urls import reverse_lazy
from django.contrib import messages
from django.db.models import Q
from .templatetags import tag
def search(request):
    query = request.POST.get("search", "").strip()
    results = []

    if query:
        results = Post.objects.filter(
            Q(title__icontains=query) |
            Q(details__icontains=query) |
            Q(resort__name__icontains=query)
        ).distinct()

    return render(request, 'hotel/search.html', {
        'query': query,
        'results': results
    })  
from django.db.models import Q

def filter(request):
    if request.method == "POST":
        resort = request.POST.get('resort')
        roomin = request.POST.get('roomin')
        if resort or roomin:
            queryset = Q()
            if roomin:
                queryset |= Q(roomin__name__icontains=roomin)
            if resort:
                queryset |= Q(resort__name__icontains=resort)

            results = Post.objects.filter(queryset).distinct()
        else:
            results = []

        context = {
            'results': results
        }
        return render(request, 'hotel/search.html', context)

   
app_name='hotel'

class ContactView(FormView):
    form_class = Contactform
    template_name = 'contact.html'
    success_url='/'
    def form_valid(self, form):
        form.save()
        messages.success(self.request,"Form Sucessfully Submitted")
        return super().form_valid(form)
    def form_invalid(self, form):
       # form.save()
        return super().form_invalid(form)
    def get_success_url(self):
        return reverse_lazy('homeview')




#class ContactView(View):
 #   form_class = Contactform
    #template_name = 'contact.html'
    #def get(self, request, *args, **kwargs):
     #   form = self.form_class()
      #  return render(request, self.template_name, {'form': form})

    #def post(self, request, *args, **kwargs):
     #   form = self.form_class(request.POST)
      #  if form.is_valid():
       #     form.save()
        #    return HttpResponse("You did job Successfully")
        #return render(request, self.template_name, {'form': form})





# Create your views here.
def home(request):
    return render(request, "home.html")
def contact(request):
    if request.method=="POST":
        form =Contactform(request.POST)
        if form.is_valid():
          form.save()
        #print(name)
       # print(phone)
       # print(content)
       # print(email)
        #obj =Contact(name=name,phone=phone,content=content, email=email)
        #obj.save()
    else:
        form =Contactform()

    return render(request, "contact.html",{'form':form})    
from django.views.generic import ListView
class PostListView(ListView):
    template_name='hotel/postlist.html'
    queryset=Post.objects.all()
    context_object_name="posts"
    def get_context_data(self, **kwargs):
        context= super().get_context_data(**kwargs)
        context["posts"]=context.get("object_list")
        context["resorts"]=Resort.objects.all()
        context["roomins"]=RoomIn.objects.all()
        context["viewtype"]=ViewType.objects.all()
        context["diningoption"]=DiningOption.objects.all()
        return context
from django.views.generic import DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404
from .models import Post

class PostDetailView(DetailView):
    model = Post
    template_name = "hotel/postdetail.html"
    

    def get_object(self, queryset=None):
        # This ensures `self.object` is properly set early
        obj = super().get_object(queryset)
        # Track unique views, if `views` is a ManyToManyField to User
        if self.request.user.is_authenticated:
            obj.views.add(self.request.user)
        return obj

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        post = self.object
        user = self.request.user
        comments=Comment.objects.filter(post=post.id,parent=None)
        replies=Comment.objects.filter(post=post.id).exclude(parent=None)
        dictreply={}
        for reply in replies:
            if reply.parent.id not in dictreply.keys():
                dictreply[reply.parent.id]=[reply]
            else:
                dictreply[reply.parent.id].append(reply)    


        liked = False
        if user.is_authenticated and post.likes.filter(id=user.id).exists():
            liked = True

        context['liked'] = liked
        context['post'] = post  # Optional, since {{ object }} already works
        context['comments']=comments
        context['dictreply']=dictreply
        context['images'] = post.post_images.all()
        context['post_files'] = post.post_files.all()
        return context

        
from django.views.generic import UpdateView,DeleteView
class PostEdit(UpdateView):
    model=Post
    form_class=postform
    template_name="hotel/postcreate.html"
    def get_success_url(self):
        id=self.object.id
        return reverse_lazy("hotel:postdetail",kwargs={'pk':id})
       # return super().get_success_url()    
class PostDeleteView(DeleteView):
    model=Post
    template_name="hotel/delete.html"
    success_url=reverse_lazy("hotel:postlists")
#comment delete
def commentdelete(request,id):
    comment=Comment.objects.get(id=id)
    comment.delete()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))

def postview(request):
    post=Post.objects.all()
    return render(request,'hotel/postview.html',{'post':post})
def resortview(request):
    resorts = Resort.objects.all()
    posts = Post.objects.prefetch_related('resort')
    return render(request, 'hotel/resortview.html', {'resorts': resorts, 'posts': posts})
from django.views.generic import CreateView
class PostCreateView (CreateView):
    model=Post
    form_class=postform
    template_name = "hotel/postcreate.html" 
   # success_url='/'
    def form_valid(self, form):
        form.instance.user=self.request.user
        return super().form_valid(form)
    def get_success_url(self):
        
       # id=self.object.id
        return reverse_lazy('hotel:resorts')
        return super().get_success_url()
def postcreate(request):
    if request.method == "POST":
        form = postform(request.POST, request.FILES)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.user = request.user
            obj.save()

            dis = form.cleaned_data['district']
            if not District.objects.filter(name=dis).exists():
                disobj = District(name=dis)
                disobj.save()

            res = form.cleaned_data['resort']
            for i in res:
                obj.resort.add(i)  # ❗ You missed passing 'i' here
            rom = form.cleaned_data['roomin']
            for i in rom:
                obj.roomin.add(i)  # ❗ Same here

            obj.save()
            viewtypes = form.cleaned_data['viewtype']
            for i in viewtypes:
                obj.viewtype.add(i)
                obj.save()

            diningoptions = form.cleaned_data['diningoption']
            for i in diningoptions:
                obj.diningoption.add(i)
                obj.save()

            return HttpResponse("success")
        else:
            # ✅ Form invalid — render the form again with errors
            return render(request, 'hotel/postcreate.html', {'form': form})
    else:
        form = postform(district_set=District.objects.all().order_by('name'))
        return render(request, 'hotel/postcreate.html', {'form': form})
# like count
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from .models import Post


def likecount(request, id):
    if request.method == 'POST':
        post = get_object_or_404(Post, id=id)
        if post.likes.filter(id=request.user.id).exists():
            post.likes.remove(request.user)
        else:
            post.likes.add(request.user)
            if post.user != request.user:
                Notification.objects.create(
                   user=post.user,
                   sender=request.user,
                   notification_type='like',
                   post=post
                 )
    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
from .models import Comment
from django.http import HttpResponseRedirect
from .models import Comment, Post

def addcomment(request):
    if request.method == "POST":
        comment_text = request.POST.get('comment')
        parentid = request.POST.get('parentid')
        postid = request.POST.get('postid')
        post = Post.objects.get(id=postid)
        user = request.user

        if parentid:
            parent = Comment.objects.get(id=parentid)
            reply = Comment(text=comment_text, user=user, post=post, parent=parent)
        else:
            reply = Comment(text=comment_text, user=user, post=post)

        reply.save()

        # ✅ Only notify if post has a user and it's not the commenter
        if post.user_id and post.user != user:
            Notification.objects.create(
                    user=post.user,
                    sender=request.user,
                    notification_type='comment',
                    post=post,
                    comment=reply
                    )

        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))


        
       # return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))
 #add photo
from .forms import FileModelForm 
from .models import PostFile
from django.urls import reverse
def addphoto(request, id):
    post = Post.objects.get(id=id)  # ✅ Corrected the query
    if request.method == "POST":
        form = FileModelForm(request.POST, request.FILES)  # ✅ request.FILES (not Files)
        if form.is_valid():
            image = form.cleaned_data['image']
            obj = PostFile(image=image, post=post)
            obj.save()
            messages.success(request, "Successfully uploaded image")
            return redirect(f"/hotel/postdetail/{id}/")
    else:
        form = FileModelForm()
    
    context = {
        'form': form,
        'id': id  # ✅ Pass 'id' to the template
    }
    return render(request, 'hotel/addphoto.html', context)
#def apply(request):




   

import requests
import json


def postapi(request):
    api_request = requests.get("http://jsonplaceholder.typicode.com/posts")
    try:
        api = json.loads(api_request.content)
    except:
        api = "error"
    return render(request, 'hotel/postlistapi.html', {'api': api})
#notification
from django.views.generic import ListView
from .models import Notification
from django.shortcuts import redirect

class NotificationListView(ListView):
    model = Notification
    template_name = "hotel/notifications.html"
    context_object_name = "notifications"

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user).order_by('-timestamp')


def mark_as_read(request, id):
    notification = Notification.objects.get(id=id)
    notification.is_read = True
    notification.save()
    return redirect('hotel:notifications')
from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView
from .models import Notification

class NotificationListView(ListView):
    model = Notification
    template_name = 'hotel/notifications.html'
    context_object_name = 'notifications'

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user).order_by('-timestamp')

def mark_as_read(request, id):
    notification = get_object_or_404(Notification, id=id)
    notification.is_read = True
    notification.save()
    # Redirect to the related post if it exists
    if notification.post:
        return redirect('hotel:postdetail', pk=notification.post.id)
    return redirect('hotel:notifications')
#conform and payment section
# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Post, Resort, RoomIn, ViewType, DiningOption
from .forms import ConfirmationForm
from datetime import datetime

def confirmation_view(request, id):
    post = get_object_or_404(Post, id=id)
    form = ConfirmationForm(request.POST or None)
    
    if form.is_valid():
        check_in = form.cleaned_data['check_in']
        check_out = form.cleaned_data['check_out']
        resort = form.cleaned_data['resort']
        roomin = form.cleaned_data['roomin']
        viewtype = form.cleaned_data['viewtype']
        diningoption = form.cleaned_data['diningoption']

        # Calculation (koto din thakbe)
        duration = (check_out - check_in).days
        
        # Cost Calculation
        base_cost = post.cost * duration
        discount_amount = (base_cost * post.discount) / 100
        total_cost = base_cost - discount_amount

        # Data pathai Payment Page e
        request.session['booking_data'] = {
            'resort': resort.name,
            'check_in': str(check_in),
            'check_out': str(check_out),
            'roomin': [r.name for r in roomin],
            'viewtype': [v.name for v in viewtype],
            'diningoption': [d.name for d in diningoption],
            'total_cost': total_cost
        }

        return redirect('hotel:payment')

    context = {
        'post': post,
        'form': form,
    }
    return render(request, 'hotel/confirmation.html', context)

# views.py
# views.py
from django.shortcuts import render, redirect

def payment_view(request):
    data = request.session.get('booking_data')
    if not data:
        return redirect('hotel:payment')

    return render(request, 'hotel/payment.html', {'data': data})

from django.http import HttpResponse

def payment_success(request):
    method = request.POST.get('method')
    return HttpResponse(f"<h2>Payment Successful with {method}!</h2><p>Thank you for your payment.</p>")
