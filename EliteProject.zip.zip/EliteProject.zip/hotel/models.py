from django.db import models
from django.utils.timezone import now
from PIL import Image
from django.utils.text import slugify
from multiselectfield import MultiSelectField
from django.contrib.auth.models import User


#Managers

class PostManager(models.Manager):
    def sorted(self, title):
        return self.order_by(title)


# Models

class Contact(models.Model):
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    content = models.TextField()

    def __str__(self):
        return self.name


class Resort(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='resort_images/', blank=True, null=True)

    def __str__(self):
        return self.name


class RoomIn(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name
    
class ViewType(models.Model):
    name=models.CharField(max_length=50)   
    def __str__(self):
        return self.name
class DiningOption(models.Model):
    name=models.CharField(max_length=50) 
    def __str__(self):
        return self.name 


class District(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Post(models.Model):
    CATEGORY = (
        ('employee', 'Employee'),
        ('guest', 'Guest'),
    )
    ROOMS = (
        ('ac', 'AC'),
        ('non_ac', 'Non-AC'),
    )

    #user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="post_set", blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="post_set")

    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=70)
    slug = models.SlugField(max_length=100, blank=True)
    email = models.EmailField()
    cost = models.IntegerField()
    discount=models.IntegerField(default=0)
   # rating=models.FloatField()
    details = models.TextField()
    available = models.BooleanField()
    category = models.CharField(max_length=100, choices=CATEGORY)
    created_at = models.DateTimeField(default=now)
    image = models.ImageField(default="default.jpg", upload_to='hotel/images')
    rooms = MultiSelectField(choices=ROOMS, max_choices=5, max_length=50, default='non_ac')
    resort = models.ManyToManyField(Resort, related_name='posts')
    roomin = models.ManyToManyField(RoomIn, related_name='posts')
    viewtype=models.ManyToManyField(ViewType,related_name='posts')
    diningoption=models.ManyToManyField(DiningOption,related_name='posts')
    district = models.CharField(max_length=100, null=True, blank=True)
    likes = models.ManyToManyField(User, related_name='post_likes', blank=True)
    views = models.ManyToManyField(User, related_name='post_views', blank=True)

    # Custom Methods
    def total_like(self):
        return self.likes.count()

    def total_view(self):
        return self.views.count()

    def details_short(self):
        details_word = self.details.split(' ')
        if len(details_word) > 20:
            return " ".join(details_word[:20]) + "..."
        else:
            return self.details


#Image Upload

class Image(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='post_images')
    image = models.ImageField(upload_to='post_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)


import os
from PIL import Image

class PostFile(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='post_files')
    image = models.ImageField(upload_to='hotel/files')

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        
        if self.image:
            try:
                img = Image.open(self.image.path)
                if img.height > 300 or img.width > 300:
                    output_size = (300, 300)
                    img.thumbnail(output_size)
                    img.save(self.image.path)
            except Exception as e:
                print(f"Image processing failed: {e}")


#   Facilities

class Facility(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='facilities')
    name = models.CharField(max_length=100)



#Reviews

class Review(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField()
    rating = models.IntegerField(default=5)
    created_at = models.DateTimeField(auto_now_add=True)



#Comment and Reply

class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField()
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='replies')
    created_at = models.DateTimeField(default=now)

    def __str__(self):
        return f"{self.user.username}: {self.text[:15]}"



#Notification

class Notification(models.Model):
    NOTIFICATION_TYPES = (
        ('like', 'Like'),
        ('comment', 'Comment'),
        ('post', 'New Post'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')  # Receiver
    sender = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='sent_notifications')  # Who triggered it
    notification_type = models.CharField(max_length=10, choices=NOTIFICATION_TYPES)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, null=True, blank=True, related_name='post_notifications')
    comment = models.ForeignKey(Comment, on_delete=models.CASCADE, null=True, blank=True, related_name='comment_notifications')
    is_read = models.BooleanField(default=False)
    timestamp = models.DateTimeField(default=now)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.notification_type}"

#room_booking sector

