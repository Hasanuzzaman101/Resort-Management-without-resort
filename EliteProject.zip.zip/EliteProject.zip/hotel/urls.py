from django.urls import path
from django.contrib import admin
from .import views
from .views import (
    home, likecount, addphoto, addcomment, contact, postapi, filter, search, postview,
    postcreate, resortview, ContactView, PostCreateView, PostListView, PostDetailView,
    PostEdit, PostDeleteView, commentdelete, NotificationListView, mark_as_read,confirmation_view, payment_view,payment_success
)
from .forms import ContactFormTwo
from .pdf import contactpdf

app_name = 'hotel'

urlpatterns = [
    path('', PostListView.as_view(), name='home'),  
    path('search/', search, name='search'),
    path('filter/', filter, name='filter'),
    path('pdf/', contactpdf, name='pdf'),
    path('likecount/<int:id>/', likecount, name='likecount'),
    path('addcomment/', addcomment, name='addcomment'),
    path('addphoto/<int:id>/', addphoto, name='addphoto'),
    path('commentdelete/<int:id>/', commentdelete, name='commentdelete'),
    path('postapi/', postapi, name='postapi'),
    path('admin/', admin.site.urls),
    path('posts/', postview, name='posts'),
    path('create/', postcreate, name='create'),
    path('resorts/', resortview, name='resorts'),
    path('contact/', ContactView.as_view(), name='contact'),
    path('postlists/', PostListView.as_view(), name='postlists'),
    path('postdetail/<int:pk>/', PostDetailView.as_view(), name='postdetail'),
    path('edit/<int:pk>', PostEdit.as_view(), name='edit'),
    path('delete/<int:pk>', PostDeleteView.as_view(), name='delete'),

    # ✅ Notifications
    path('notifications/', NotificationListView.as_view(), name='notifications'),
    path('notifications/read/<int:id>/', mark_as_read, name='mark_as_read'),
    #conform and payment
    # urls.py
    path('confirmation/<int:id>/', confirmation_view, name='confirmation'),
    path('payment/', payment_view, name='payment'),
     path('payment/success/', payment_success, name='payment_success'),
    

]
# urls.py


