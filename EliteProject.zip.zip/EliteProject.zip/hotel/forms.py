from django import forms
from .models import Contact,Post
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class Contactform(forms.ModelForm):
    class Meta:
        model = Contact
        fields='__all__'
class ContactFormTwo(forms.ModelForm):
    class Meta:
        model = Contact
        fields='__all__'        
from .fields import ListTextWidget
class postform(forms.ModelForm):
    class Meta:
        model = Post
        exclude = ['user', 'id', 'created_a', 'slug', 'likes', 'views']
        widgets = {
            'roomin': forms.CheckboxSelectMultiple(attrs={'multiple': True}),
            'resort': forms.CheckboxSelectMultiple(attrs={'multiple': True}),
            'viewtype':forms.CheckboxSelectMultiple(attrs={'mutiple':True}),
            'diningoption':forms.CheckboxSelectMultiple(attrs={'mutiple':True})

        }
    def __init__(self, *args, **kwargs):
        district_set=kwargs.pop('district_set',None)
        super(postform,self).__init__(*args, **kwargs)
        self.fields['district'].widget=ListTextWidget(data_list=district_set,name='district_set')

        #fields='__all__'  
from .models import PostFile
class FileModelForm(forms.ModelForm):
    class Meta:
        model=PostFile
        fields=['image']
#confirm
# forms.py
# forms.py
from django import forms
from .models import Resort, RoomIn, ViewType, DiningOption

class ConfirmationForm(forms.Form):
    check_in = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), label="Check-in Date")
    check_out = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), label="Check-out Date")
    resort = forms.ModelChoiceField(queryset=Resort.objects.all(), label="Select Resort")
    roomin = forms.ModelMultipleChoiceField(queryset=RoomIn.objects.all(), widget=forms.CheckboxSelectMultiple, label="Select Room Type")
    viewtype = forms.ModelMultipleChoiceField(queryset=ViewType.objects.all(), widget=forms.CheckboxSelectMultiple, label="Select View Type")
    diningoption = forms.ModelMultipleChoiceField(queryset=DiningOption.objects.all(), widget=forms.CheckboxSelectMultiple, label="Select Dining Option")

      


    

