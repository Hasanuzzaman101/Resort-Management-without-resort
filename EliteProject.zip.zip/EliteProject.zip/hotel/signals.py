from django.db.models.signals import post_save, m2m_changed
from django.dispatch import receiver
from .models import Comment, Post, Notification,User

# Notify on comment
@receiver(post_save, sender=Comment)
def create_comment_notification(sender, instance, created, **kwargs):
    if created and instance.post.user != instance.user:
        Notification.objects.create(
            sender=instance.user,
            receiver=instance.post.user,
            notification_type='comment',
            post=instance.post,
            comment=instance
        )

# Notify on like
@receiver(m2m_changed, sender=Post.likes.through)
def create_like_notification(sender, instance, action, pk_set, **kwargs):
    if action == "post_add":
        for pk in pk_set:
            user = User.objects.get(pk=pk)
            if user != instance.user:
                Notification.objects.create(
                    sender=user,
                    receiver=instance.user,
                    notification_type='likes',
                    post=instance
                )
