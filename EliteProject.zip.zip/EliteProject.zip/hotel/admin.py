from django.contrib import admin
from django.utils.html import format_html  # ✅ Added this
from django.utils import timezone
from .models import Contact, Post, Resort, RoomIn,Comment,PostFile, District,Notification,ViewType,DiningOption

# Customize admin site headers
admin.site.site_title = "EliteGo Admin Panel"
admin.site.index_title = ""
admin.site.site_header = "EliteGo Admin Panel"

# Post admin customization
class CommentInline(admin.TabularInline):
    model=Comment
class PostFileLine(admin.TabularInline):
    model=PostFile    
class PostAdmin(admin.ModelAdmin):
    exclude = ('user',)  # ❌ Don't exclude 'title' since you're using it below
    readonly_fields = ('slug',)
    list_display = ('user', 'title_display',  'created_at', 'created_since', 'get_resorts', 'cost')
    list_filter = ('user', 'resort', 'roomin')
    search_fields = ('details', 'user__username', 'resort__name', 'roomin__name')
    filter_horizontal = ('resort', 'roomin','viewtype','diningoption')
    list_editable = ('cost',)
    inlines=[
        CommentInline,
        PostFileLine,
    ]
    def get_viewtypes(self, obj):
        return ", ".join([v.name for v in obj.viewtype.all()])

    def get_diningoptions(self, obj):
        return ", ".join([d.name for d in obj.diningoption.all()])

    get_viewtypes.short_description = 'View Types'
    get_diningoptions.short_description = 'Dining Options'

    def created_since(self, obj):
        diff = timezone.now() - obj.created_at
        return f"{diff.days} days ago"
    created_since.short_description = 'Since Created'

    def get_resorts(self, obj):
        return ", ".join([p.name for p in obj.resort.all()])
    get_resorts.short_description = 'Resorts'

    def title_display(self, obj):
        return format_html(
            f'<span style="font-size: 20px; color: blue;">{obj.title}</span>'
        )
    title_display.short_description = "Title"  # Optional: to rename column

# Register models
admin.site.register(Contact)
admin.site.register(Post, PostAdmin)
admin.site.register(Resort)
admin.site.register(RoomIn)
admin.site.register(Comment)
admin.site.register(PostFile)
admin.site.register(District)
admin.site.register(Notification)
admin.site.register(ViewType)
admin.site.register(DiningOption)


