from django.urls import path
from .views import (
    loginuser,
    Logoutuser,
    regestration,
    ChangePassword,
    userprofile,
    ownprofile,
    Resortprofile,
    otherprofile,
    resort_list,
    resort_detail,
    resort_edit,
    resort_delete,
    all_users,chat_view
)

app_name = "seassion"

urlpatterns = [
    path('login/', loginuser, name='login'),
    path('logout/', Logoutuser, name='logout'),
    path('profile/', userprofile, name='profile'),  
    path('signup/', regestration, name='signup'),   
    path('changepass/', ChangePassword, name='changepass'),
    path('ownerprofile/', ownprofile, name='ownerprofile'),
    path('resortprofile/', Resortprofile, name='resortprofile'),
    path('otherprofile/<str:username>/', otherprofile, name='otherprofile'),
   
    path('resorts/', resort_list, name='resorts'),
    path('resortsdetail/<int:pk>/', resort_detail, name='resortsdetail'),

    path('edit/<int:pk>/', resort_edit, name='edit'),
    path('delete/<int:pk>/', resort_delete, name='delete'),  

    #msg
    path('alluser/', all_users, name='alluser'),
    path('chatviewmessenger/<str:username>/',chat_view, name='chatview'),    
  # Removed `views.`
]
