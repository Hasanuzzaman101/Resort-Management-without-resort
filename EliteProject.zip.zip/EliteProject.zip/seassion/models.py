from django.db import models
from django.contrib.auth.models import User
from hotel.models import District,Resort,RoomIn,DiningOption,ViewType
from multiselectfield import MultiSelectField
from PIL import Image

# User profile creation
class UserProfile(models.Model):
    GENRE_CHOICES = (
        ('male', 'male'),
        ('female', 'female'),
        ('custom', 'custom')
    )
    CATEGORY = (
        ('guest', 'guest'),
        ('employee', 'employee')
    )
    BLOOD_GROUP = (
        ('A-', 'A-'),
        ('A+', 'A+'),
        ('AB+', 'AB+'),
        ('AB-', 'AB-'),
        ('O+', 'O+'),
        ('O-', 'O-'),
        ('B+', 'B+'),
        ('B-', 'B-')
    )
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    birth_date = models.DateField() 
    blood_group = models.CharField(max_length=3, choices=BLOOD_GROUP)
    gender = models.CharField(max_length=6, choices=GENRE_CHOICES) 
    address = models.CharField(max_length=150)
    phone = models.CharField(max_length=50)
    nationality = models.CharField(max_length=50)
    religion = models.CharField(max_length=50)
    image = models.ImageField(default='default.jpg', upload_to='seassion/images')

    def __str__(self):
        return f'{self.user.username} profile'

    def save(self):
        super().save()  
        
        img = Image.open(self.image.path)
        if img.height > 300 or img.width > 300:
            output_size = (300, 300)
            img.thumbnail(output_size)
            img.save(self.image.path)

class Eliteprofile(models.Model):
     # --- Status Options ---
    STATUS = (
        ('Available', 'Available'),
        ('Booked', 'Booked'),
        ('Maintenance', 'Maintenance'),
    )

    # --- Room Type Choices ---
# ROOM_TYPE = (
#     ('Standard', 'Standard'),
#     ('Deluxe', 'Deluxe'),
#     ('Suite', 'Suite'),
#     ('Family', 'Family'),
# )

# --- View Choices ---
# VIEW_TYPE = (
#     ('Sea View', 'Sea View'),
#     ('Garden View', 'Garden View'),
#     ('Mountain View', 'Mountain View'),
#     ('City View', 'City View'),
# )

# --- Dining Options ---
# DINING_OPTIONS = (
#     ('Buffet', 'Buffet'),
#     ('Continental', 'Continental'),
#     ('Full English', 'Full English'),
#     ('Room Service', 'Room Service'),
# )

    # --- Basic Information ---
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='eliteprofile',default=1)


    name = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    contact_number = models.CharField(max_length=20)
    email = models.EmailField()
    status = models.CharField(max_length=20, choices=STATUS, default='Available')
   # room_type = models.CharField(max_length=20, choices=ROOM_TYPE, default='Standard')
  #  view_type = models.CharField(max_length=20, choices=VIEW_TYPE, default='City View')
   # dining_option = models.CharField(max_length=20, choices=DINING_OPTIONS, default='Buffet')
    # --- Dates ---
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    wifi = models.BooleanField(default=True)
    parking = models.BooleanField(default=True)
    pool_access = models.BooleanField(default=False)
    cost_per_night = models.DecimalField(max_digits=10, decimal_places=2)
    discount = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    resort = models.ManyToManyField(Resort, related_name='posts_elite')
    roomin = models.ManyToManyField(RoomIn, related_name='posts_elite')
    viewtype=models.ManyToManyField(ViewType,related_name='posts_elite')
    diningoption=models.ManyToManyField(DiningOption,related_name='posts_elite')

    #conversation
    # models.py

from django.db import models
from django.contrib.auth.models import User

class Conversation(models.Model):
    participants = models.ManyToManyField(User)
    updated_at = models.DateTimeField(auto_now=True)

class Message(models.Model):
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name="messages")
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField(blank=True)
    image = models.ImageField(upload_to='chat_images/', blank=True, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)



