from django.contrib import admin
from .models import UserProfile,Eliteprofile


admin.site.register(UserProfile),
admin.site.register(Eliteprofile)

# Register your models here.
