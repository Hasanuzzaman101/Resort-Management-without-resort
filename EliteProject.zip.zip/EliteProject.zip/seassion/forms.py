from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.contrib.auth.models import User
class SignUpForm(UserCreationForm):
    class Meta:
        model=User
        fields={'username','email','first_name','last_name'}
#from django import forms
from .models import UserProfile,Eliteprofile

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        exclude = ('user',)  # Exclude only the user, which will be set in the view
        widgets = {
            'birth_date': forms.DateInput(attrs={'type': 'date'}),
            'address': forms.TextInput(attrs={'placeholder': 'Enter address'}),
            'phone': forms.TextInput(attrs={'placeholder': 'Enter phone number'}),
            'nationality': forms.TextInput(attrs={'placeholder': 'Enter nationality'}),
            'religion': forms.TextInput(attrs={'placeholder': 'Enter religion'}),
            'image': forms.ClearableFileInput(),
        }
class EliteprofileForm(forms.ModelForm):
    class Meta:
        model = Eliteprofile
        exclude = ('user',)  # User will be set in the view
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Enter Resort Name'}),
            'location': forms.TextInput(attrs={'placeholder': 'Enter Resort Location'}),
            'contact_number': forms.TextInput(attrs={'placeholder': 'Enter Contact Number'}),
            'email': forms.EmailInput(attrs={'placeholder': 'Enter Email Address'}),
            'status': forms.Select(attrs={'class': 'form-control'}),
            'wifi': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'parking': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'pool_access': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'cost_per_night': forms.NumberInput(attrs={'placeholder': 'Enter Cost per Night', 'step': '0.01'}),
            'roomin': forms.CheckboxSelectMultiple(attrs={'multiple': True}),
            'resort': forms.CheckboxSelectMultiple(attrs={'multiple': True}),
            'viewtype':forms.CheckboxSelectMultiple(attrs={'mutiple':True}),
            'diningoption':forms.CheckboxSelectMultiple(attrs={'mutiple':True}),
            'discount': forms.NumberInput(attrs={'placeholder': 'Enter Discount (if any)', 'step': '0.01'}),
            'created_at': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'updated_at': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        }
class ResortForm(forms.ModelForm):
    class Meta:
        model = Eliteprofile
        exclude = ['user', 'created_at', 'updated_at']        
        



        
