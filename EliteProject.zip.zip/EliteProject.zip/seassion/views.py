from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Count

from .forms import SignUpForm, UserProfileForm, EliteprofileForm, ResortForm
from .models import UserProfile, Eliteprofile, Conversation, Message

# Home View (Authenticated users only)
@login_required(login_url='seassion:login')
def homeview(request):
    return render(request, 'hotel/home.html')

# Login View
def loginuser(request):
    if request.method == "POST":
        form = AuthenticationForm(request=request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('homeview')
            else:
                messages.error(request, "Invalid username or password")
        else:
            messages.error(request, "Invalid username or password")
    else:
        form = AuthenticationForm()
    return render(request, 'seassion/login.html', {'form': form})

# Logout View
@login_required
def Logoutuser(request):
    logout(request)
    messages.success(request, "Successfully logged out")
    return redirect('homeview')

# Registration View
def regestration(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('seassion:login')
    else:
        form = SignUpForm()
    return render(request, 'seassion/signup.html', {'form': form})

# Change Password View
@login_required
def ChangePassword(request):
    if request.method == "POST":
        form = PasswordChangeForm(data=request.POST, user=request.user)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
            messages.success(request, "Successfully password changed")
            return redirect('homeview')
    else:
        form = PasswordChangeForm(user=request.user)
    return render(request, 'seassion/changepass.html', {'form': form})

# User Profile View
@login_required
def userprofile(request):
    try:
        instance = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        instance = None

    if request.method == "POST":
        form = UserProfileForm(request.POST, request.FILES, instance=instance)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.user = request.user
            obj.save()
            messages.success(request, "Successfully created your profile")
            return redirect('homeview')
    else:
        form = UserProfileForm(instance=instance)

    return render(request, 'seassion/profile.html', {'form': form})

# Create or Update Elite Profile (Resort Profile)
@login_required
def Resortprofile(request):
    try:
        instance = Eliteprofile.objects.get(user=request.user)
    except Eliteprofile.DoesNotExist:
        instance = None

    if request.method == "POST":
        form = EliteprofileForm(request.POST, instance=instance)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.user = request.user
            obj.save()
            messages.success(request, "Successfully Posted")
            return redirect('seassion:resortprofile')
    else:
        form = EliteprofileForm(instance=instance)

    return render(request, 'seassion/eliteprofile.html', {'form': form})

# Own Profile View
@login_required
def ownprofile(request):
    return render(request, 'seassion/profileshow.html', {'user': request.user})

# View Other User Profile
@login_required
def otherprofile(request, username):
    user = get_object_or_404(User, username=username)
    return render(request, 'seassion/otherprofle.html', {'user': user})

# Resort List View (public)
def resort_list(request):
    resorts = Eliteprofile.objects.all().order_by('-created_at')
    return render(request, 'seassion/resort_list.html', {'resorts': resorts})

# Resort Detail View (public)
def resort_detail(request, pk):
    resort = get_object_or_404(Eliteprofile, pk=pk)
    return render(request, 'seassion/resort_detail.html', {'resort': resort})

# Edit Resort View
@login_required
def resort_edit(request, pk):
    resort = get_object_or_404(Eliteprofile, pk=pk)
    if resort.user != request.user:
        return redirect('seassion:resorts')

    if request.method == 'POST':
        form = ResortForm(request.POST, instance=resort)
        if form.is_valid():
            form.save()
            return redirect('seassion:resortsdetail', pk=pk)
    else:
        form = ResortForm(instance=resort)

    return render(request, 'seassion/resort_edit.html', {'form': form})

# Delete Resort View
@login_required
def resort_delete(request, pk):
    resort = get_object_or_404(Eliteprofile, pk=pk)
    if resort.user != request.user:
        return redirect('seassion:resorts')

    if request.method == 'POST':
        resort.delete()
        return redirect('seassion:resorts')

    return render(request, 'seassion/resort_confirm_delete.html', {'resort': resort})

# All Users List for Chat
@login_required
def all_users(request):
    users = User.objects.exclude(id=request.user.id)
    return render(request, 'seassion/allusers.html', {'users': users})

# Chat View
@login_required
def chat_view(request, username):
    other_user = get_object_or_404(User, username=username)

    # Find existing conversation
    conversation = (
        Conversation.objects
        .filter(participants=request.user)
        .filter(participants=other_user)
        .annotate(num_participants=Count('participants'))
        .filter(num_participants=2)
        .first()
    )

    if not conversation:
        conversation = Conversation.objects.create()
        conversation.participants.add(request.user, other_user)

    if request.method == "POST":
        text = request.POST.get('text', '').strip()
        image = request.FILES.get('image')

        if text or image:
            Message.objects.create(
                conversation=conversation,
                sender=request.user,
                text=text,
                image=image
            )
        return redirect('seassion:chatview', username=other_user.username)

    messages_qs = conversation.messages.all().order_by('timestamp')

    # Load all conversations for the sidebar
    conversations = (
        Conversation.objects
        .filter(participants=request.user)
        .annotate(num_participants=Count('participants'))
        .filter(num_participants=2)
    )

    convo_list = []
    for convo in conversations:
        other = convo.participants.exclude(id=request.user.id).first()
        convo_list.append({
            'conversation': convo,
            'other_user': other,
            'unread_count': 0  # Add logic here if needed
        })

    return render(request, 'seassion/chatview.html', {
        'conversation': conversation,
        'messages': messages_qs,
        'other_user': other_user,
        'conversations': convo_list
    })
