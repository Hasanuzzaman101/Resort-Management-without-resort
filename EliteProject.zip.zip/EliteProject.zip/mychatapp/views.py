from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from .models import Message
from django.db.models import Q
from django.core.serializers.json import DjangoJSONEncoder
from django.utils.timezone import localtime


@login_required
def chat_view(request):
    users = User.objects.exclude(id=request.user.id)

    # Add unread count (optional)
    for user in users:
        user.unread = Message.objects.filter(
            sender=user,
            receiver=request.user,
            is_read=False
        ).count()

    return render(request, 'mychatapp/index.html', {'users': users})


@csrf_exempt
@login_required
def send_message(request, username):
    if request.method == "POST":
        text = request.POST.get("message", "")
        image = request.FILES.get("image", None)

        receiver = User.objects.get(username=username)
        Message.objects.create(
            sender=request.user,
            receiver=receiver,
            text=text,
            image=image
        )
        return JsonResponse({"status": "success"})

    return JsonResponse({"status": "error", "message": "Only POST allowed."}, status=400)


@login_required
def chat_history(request, username):
    other_user = User.objects.get(username=username)

    messages = Message.objects.filter(
        Q(sender=request.user, receiver=other_user) |
        Q(sender=other_user, receiver=request.user)
    ).order_by('timestamp')

    message_list = []
    for msg in messages:
        message_list.append({
            'sender': msg.sender.username,
            'text': msg.text,
            'image': msg.image.url if msg.image else None,
            'timestamp': localtime(msg.timestamp).strftime('%Y-%m-%d %H:%M')
        })

    return JsonResponse({'messages': message_list}, encoder=DjangoJSONEncoder)
