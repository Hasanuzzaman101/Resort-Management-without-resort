from django.urls import path
from .import views

urlpatterns = [
    path('chats/',views.chat_view,name="index"),
    path('send_message/<str:username>/', views.send_message, name='send_message'),
    path('history/<str:username>/', views.chat_history, name='chat_history'),

]
